﻿namespace Sistema_On_Tour.Vistas
{
    partial class VentanaContratos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VentanaContratos));
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.BtnVolver = new System.Windows.Forms.Button();
            this.BtnDescargarCont = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.BtnDescargarPlan = new System.Windows.Forms.Button();
            this.BtnDescargarCond = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(151, 224);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(277, 24);
            this.label3.TabIndex = 25;
            this.label3.Text = "Condiciones de Gira de Estudio";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(151, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 24);
            this.label2.TabIndex = 24;
            this.label2.Text = "Contrato Paquete";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // BtnVolver
            // 
            this.BtnVolver.BackColor = System.Drawing.SystemColors.Control;
            this.BtnVolver.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnVolver.BackgroundImage")));
            this.BtnVolver.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnVolver.Cursor = System.Windows.Forms.Cursors.Default;
            this.BtnVolver.Location = new System.Drawing.Point(25, 51);
            this.BtnVolver.Name = "BtnVolver";
            this.BtnVolver.Size = new System.Drawing.Size(74, 72);
            this.BtnVolver.TabIndex = 23;
            this.BtnVolver.UseVisualStyleBackColor = false;
            this.BtnVolver.Click += new System.EventHandler(this.BtnVolver_Click);
            // 
            // BtnDescargarCont
            // 
            this.BtnDescargarCont.Font = new System.Drawing.Font("Perpetua", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDescargarCont.Location = new System.Drawing.Point(544, 162);
            this.BtnDescargarCont.Name = "BtnDescargarCont";
            this.BtnDescargarCont.Size = new System.Drawing.Size(108, 29);
            this.BtnDescargarCont.TabIndex = 22;
            this.BtnDescargarCont.Text = "Descargar";
            this.BtnDescargarCont.UseVisualStyleBackColor = true;
            this.BtnDescargarCont.Click += new System.EventHandler(this.BtnDescargarCont_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(194, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(426, 37);
            this.label1.TabIndex = 21;
            this.label1.Text = "Agencia de Viajes On Tour";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(151, 285);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(363, 24);
            this.label4.TabIndex = 26;
            this.label4.Text = "Planes de Acción en caso de emergencia";
            // 
            // BtnDescargarPlan
            // 
            this.BtnDescargarPlan.Font = new System.Drawing.Font("Perpetua", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDescargarPlan.Location = new System.Drawing.Point(544, 285);
            this.BtnDescargarPlan.Name = "BtnDescargarPlan";
            this.BtnDescargarPlan.Size = new System.Drawing.Size(108, 29);
            this.BtnDescargarPlan.TabIndex = 27;
            this.BtnDescargarPlan.Text = "Descargar";
            this.BtnDescargarPlan.UseVisualStyleBackColor = true;
            this.BtnDescargarPlan.Click += new System.EventHandler(this.BtnDescargarPlan_Click);
            // 
            // BtnDescargarCond
            // 
            this.BtnDescargarCond.Font = new System.Drawing.Font("Perpetua", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDescargarCond.Location = new System.Drawing.Point(544, 219);
            this.BtnDescargarCond.Name = "BtnDescargarCond";
            this.BtnDescargarCond.Size = new System.Drawing.Size(108, 29);
            this.BtnDescargarCond.TabIndex = 28;
            this.BtnDescargarCond.Text = "Descargar";
            this.BtnDescargarCond.UseVisualStyleBackColor = true;
            this.BtnDescargarCond.Click += new System.EventHandler(this.BtnDescargarCond_Click);
            // 
            // VentanaContratos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnDescargarCond);
            this.Controls.Add(this.BtnDescargarPlan);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnVolver);
            this.Controls.Add(this.BtnDescargarCont);
            this.Controls.Add(this.label1);
            this.Name = "VentanaContratos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VentanaContratos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BtnVolver;
        private System.Windows.Forms.Button BtnDescargarCont;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BtnDescargarPlan;
        private System.Windows.Forms.Button BtnDescargarCond;
    }
}