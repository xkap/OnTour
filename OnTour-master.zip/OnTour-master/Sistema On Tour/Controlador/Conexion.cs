﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.DataAccess.Client;

namespace Sistema_On_Tour.Controlador
{
    public static class Conexion
    {

        public static string conn = "DATA SOURCE=PC-CHINO:1521/xe;USER ID = ONTOUR; PASSWORD=ontour";

    }
}
