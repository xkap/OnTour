# OnTour desktop application using Oracle DB and MVC design pattern

This is a desktop app built using C# and an Oracle DB. The MVC design pattern was used here.

### This was a university assignment for a subject in the 3rd semester of my CS course. How it was coded does not represent the way I code today.
